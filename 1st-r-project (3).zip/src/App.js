import React from "react";
import "./styles.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./PAGE/home";
import About from "./PAGE/about";
import Photo from "./PAGE/my-photo";
import Resume from "./PAGE/resume";
import Navbar from "./navbar";
import Footer from "./footer";
function App() {
  return (
    <section className="App">
      <div className="header">
        <div className="iii">
          <i class="fa-solid fa-section"></i>
          uthar APP
        </div>

        <Router>
          <Navbar />
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/photo" element={<Photo />} />
            <Route path="/resume" element={<Resume />} />
          </Routes>
        </Router>
      </div>
      <div className="footer">
        <Footer />
      </div>
    </section>
  );
}

export default App;
